<!DOCTYPE html>
<html>
<head>
	<title>login</title>
</head>
<body>
<form method="post" action="function.php">
		<table>
			<tr>
				<td>email</td>
				<td>:</td>
				<td><input type="text" name="email" placeholder="Masukkan email"></td>
			</tr>
			<tr>
				<td>Password</td>
				<td>:</td>
				<td><input type="password" name="password" placeholder="Masukkan password"></td>
			</tr>
			<tr>
				<td></td>
				<td></td>
				<td><input type="submit" value="LOGIN"></td>
			</tr>
		</table>			
		<a href="index.php">registeasi</a>
	</form>
</body>
</html>