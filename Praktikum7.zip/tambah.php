<html>
<head><title>Register</title></head>
<body>
<label>SIlahkan Input Data</label>
<br>
	<form method="POST" action="proslogin.php" enctype="multipart/form-data">
		<br>
		<label>Nama</label>
		<br>
		<input type="text" name="nama"/>
		<br>
		<label>Tgl lahir</label>
		<br>
		<input type="text" name="tgl"/>
		<br>
		<label>Tmpt Lahir</label>
		<br>
		<input type="text" name="tmp"/>
		<br>
		<label>Upload Foto</label>
		<br>
		<input type="file" name="foto">
		<br><br>
		<input type="reset" name="reset">
		<input type="submit" name="submit">
	</form>
	<br>
</body>
