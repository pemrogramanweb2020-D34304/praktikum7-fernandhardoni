<? 
session_start();
session_destroy();
echo "anda sudah logout";
echo "<br>";
echo "<a href=login.php>silahkan login</a>"
?>